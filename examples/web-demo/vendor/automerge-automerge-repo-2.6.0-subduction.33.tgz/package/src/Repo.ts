import { next as Automerge, Heads } from "@automerge/automerge/slim"
import { makeLogger } from "./Logger.js"
import { EventEmitter } from "eventemitter3"
import {
  binaryToDocumentId,
  generateAutomergeUrl,
  interpretAsDocumentId,
  isValidAutomergeUrl,
  parseAutomergeUrl,
} from "./AutomergeUrl.js"
import { DocHandle, type CrdtDocHandle } from "./DocHandle.js"
import type { DocumentSource } from "./DocumentSource.js"
import {
  DocumentQuery,
  progressAtHeads,
  progressAtPath,
  type DocumentProgress,
} from "./DocumentQuery.js"
import { RemoteHeadsSubscriptions } from "./RemoteHeadsSubscriptions.js"
import { StorageSource } from "./StorageSource.js"
import { SyncStateTracker } from "./SyncStateTracker.js"
import {
  NetworkAdapterInterface,
  type PeerMetadata,
} from "./network/NetworkAdapterInterface.js"
import { NetworkSubsystem } from "./network/NetworkSubsystem.js"
import { RepoMessage } from "./network/messages.js"
import { StorageAdapterInterface } from "./storage/StorageAdapterInterface.js"
import { StorageSubsystem } from "./storage/StorageSubsystem.js"
import { StorageId } from "./storage/types.js"
import { CollectionSynchronizer } from "./synchronizer/CollectionSynchronizer.js"
import type {
  AnyDocumentId,
  AutomergeUrl,
  BinaryDocumentId,
  DocumentId,
  PeerId,
  SessionId,
} from "./types.js"
import { AbortOptions, AbortError } from "./helpers/abortable.js"
import {
  MemorySigner,
  set_subduction_logger,
  type Subduction,
} from "@automerge/automerge-subduction/slim"
import {
  SubductionStorageBridge,
  INTERCEPTOR_PREFIX,
} from "./subduction/storage.js"
import { DummyStorageAdapter } from "./helpers/DummyStorageAdapter.js"
import {
  SubductionSource,
  type SubductionTimeouts,
  type BlobInterceptor,
} from "./subduction/source.js"
import type { Policy as SubductionPolicy } from "@automerge/automerge-subduction/slim"
import { encode, decode } from "cbor-x"
import type { EphemeralMessage } from "./network/messages.js"
export type { FindProgressWithMethods, ProgressSignal } from "./_compat.js"
import { Document } from "./Document.js"
import { truePromiseFactory } from "./helpers/truePromiseFactory.js"
import {
  automergeDocType,
  isDocumentType,
  type AnyDocumentType,
  type InitOf,
} from "./crdt.js"

export type { DocumentProgress } from "./DocumentQuery.js"
export { DocumentQuery } from "./DocumentQuery.js"

let subductionLoggingEnabled = false

function randomPeerId() {
  return ("peer-" + Math.random().toString(36).slice(4)) as PeerId
}

/** A Repo is a collection of documents with networking, syncing, and storage capabilities. */
/** The `Repo` is the main entry point of this library
 *
 * @remarks
 * To construct a `Repo` you will need an {@link StorageAdapter} and one or
 * more {@link NetworkAdapter}s. Once you have a `Repo` you can use it to
 * obtain {@link DocHandle}s.
 */
export class Repo extends EventEmitter<RepoEvents> {
  #log = makeLogger("automerge-repo:repo")

  /** @hidden */
  networkSubsystem: NetworkSubsystem
  /** @hidden */
  storageSubsystem?: StorageSubsystem

  #queries: Record<DocumentId, DocumentQuery<any, DocHandle<any, any>>> = {}

  /** @hidden */
  synchronizer: CollectionSynchronizer

  #sources = new Map<string, DocumentSource>()

  #automergeDocumentType = automergeDocType()

  #shareConfig: ShareConfig = {
    announce: truePromiseFactory,
    access: truePromiseFactory,
  }

  /** maps peer id to to persistence information (storageId, isEphemeral), access by collection synchronizer  */
  /** @hidden */
  peerMetadataByPeerId: Record<PeerId, PeerMetadata> = {}

  #syncStateTracker: SyncStateTracker
  #remoteHeadsSubscriptions = new RemoteHeadsSubscriptions()
  #remoteHeadsGossipingEnabled = false
  #subductionSource: SubductionSource | null = null
  #subductionEphemeralCount = 0
  #idFactory: ((initialHeads: Heads) => Promise<Uint8Array>) | null
  #peerId: PeerId

  constructor({
    storage,
    network = [],
    peerId = randomPeerId(),
    sharePolicy,
    shareConfig,
    isEphemeral = storage === undefined,
    enableRemoteHeadsGossiping = false,
    denylist = [],
    saveDebounceRate = 100,
    idFactory,
    signer,
    subductionPolicy,
    subductionWebsocketEndpoints,
    subductionAdapters,
    subductionTimeouts,
    subductionBlobInterceptor,
  }: RepoConfig = {}) {
    super()
    this.#peerId = peerId
    this.#remoteHeadsGossipingEnabled = enableRemoteHeadsGossiping

    this.#idFactory = idFactory || null
    // Handle legacy sharePolicy
    if (sharePolicy != null && shareConfig != null) {
      throw new Error("cannot provide both sharePolicy and shareConfig at once")
    }
    if (sharePolicy) {
      this.#shareConfig = {
        announce: sharePolicy,
        access: truePromiseFactory,
      }
    }
    if (shareConfig) {
      this.#shareConfig = shareConfig
    }

    // STORAGE
    const storageSubsystem = storage ? new StorageSubsystem(storage) : undefined
    if (storageSubsystem) {
      storageSubsystem.on("document-loaded", event =>
        this.emit("doc-metrics", { type: "doc-loaded", ...event })
      )
      storageSubsystem.on("doc-compacted", event =>
        this.emit("doc-metrics", { type: "doc-compacted", ...event })
      )
      storageSubsystem.on("doc-saved", event =>
        this.emit("doc-metrics", { type: "doc-saved", ...event })
      )
    }

    if (!subductionLoggingEnabled) {
      subductionLoggingEnabled = true
      set_subduction_logger(
        (level: string, target: string, message: string, fields: any) => {
          const log = makeLogger(`automerge-repo:subduction:${target}`)

          const hasFields = fields && Object.keys(fields).length > 0
          const formattedMessage = hasFields
            ? `${message} ${JSON.stringify(fields)}`
            : message

          // Prefix the level so it's visible regardless of which backend the
          // Logger factory routes to.
          log.debug(`[${level}] ${formattedMessage}`)
        }
      )
    }
    // Subduction commits are persisted under a key prefix that depends on
    // whether a blob interceptor is configured. A Repo with an interceptor
    // uses INTERCEPTOR_PREFIX. One without uses the default. This keeps the
    // two representations apart when two Repos share one storage but only one
    // of them runs the interceptor. Without separate prefixes, an
    // interceptor-transformed commit and an untransformed commit with the same
    // CommitId would collide at the same key and clobber each other.
    let subductionStorage: SubductionStorageBridge
    if (storage) {
      subductionStorage = new SubductionStorageBridge(
        storage,
        subductionBlobInterceptor ? INTERCEPTOR_PREFIX : undefined
      )
    } else {
      subductionStorage = new SubductionStorageBridge(new DummyStorageAdapter())
    }
    const subductionSource = new SubductionSource({
      peerId,
      storage: subductionStorage,
      signer: signer ?? new MemorySigner(),
      websocketEndpoints: subductionWebsocketEndpoints ?? [],
      adapters: subductionAdapters ?? [],
      policy: subductionPolicy,
      timeouts: subductionTimeouts,
      blobInterceptor: subductionBlobInterceptor,
      onRemoteHeadsChanged: enableRemoteHeadsGossiping
        ? (documentId, storageId, heads) => {
            this.#remoteHeadsSubscriptions.handleImmediateRemoteHeadsChanged(
              documentId,
              storageId,
              heads
            )
          }
        : undefined,
      onEphemeral: (sedimentreeId, _senderId, payload) => {
        try {
          const msg = decode(new Uint8Array(payload)) as EphemeralMessage
          this.synchronizer.receiveMessage(msg)
        } catch (e) {
          this.#log.error("failed to decode inbound subduction ephemeral", {
            err: e,
          })
        }
      },
      onHealExhausted: documentId => {
        this.emit("heal-exhausted", { documentId })
      },
    })
    this.#subductionSource = subductionSource
    this.#sources.set("subduction", subductionSource)

    this.storageSubsystem = storageSubsystem
    this.#syncStateTracker = new SyncStateTracker(
      this.storageSubsystem,
      saveDebounceRate
    )

    if (storageSubsystem) {
      this.#sources.set(
        "storage",
        new StorageSource(storageSubsystem, saveDebounceRate)
      )
    }

    // NETWORK
    const myPeerMetadata: Promise<PeerMetadata> = (async () => ({
      storageId: await storageSubsystem?.id(),
      isEphemeral,
    }))()

    const networkSubsystem = new NetworkSubsystem(
      network,
      peerId,
      myPeerMetadata
    )
    this.networkSubsystem = networkSubsystem

    // COLLECTION SYNCHRONIZER
    this.synchronizer = new CollectionSynchronizer(
      {
        peerId,
        shareConfig: this.#shareConfig,
        priority: 0,
        ensureQuery: id => this.#ensureQuery(id),
        loadSyncState: async (documentId, pid) => {
          if (!this.storageSubsystem) return
          const { storageId, isEphemeral: isEph } =
            this.peerMetadataByPeerId[pid] || {}
          if (!storageId || isEph) return
          return this.storageSubsystem.loadSyncState(documentId, storageId)
        },
        networkReady: networkSubsystem.whenReady().then(() => {}),
      },
      denylist
    )
    this.#sources.set("automerge-sync", this.synchronizer)

    // When the synchronizer emits messages, send them to peers
    this.synchronizer.on("message", message => {
      this.#log.debug(`sending ${message.type} message to ${message.targetId}`)
      networkSubsystem.send(message)
    })

    // Tunnel inbound ephemeral messages from network adapters through
    // subduction, so they reach peers connected via websocket transport.
    networkSubsystem.on("message", message => {
      if (message.type === "ephemeral" && this.#subductionSource) {
        const payload = new Uint8Array(encode(message))
        void this.#subductionSource.publishEphemeral(
          message.documentId,
          payload
        )
      }
    })

    // Forward sync metrics events
    this.synchronizer.on("metrics", event => this.emit("doc-metrics", event))

    // Track which peers have which documents open (for remote heads gossiping)
    this.synchronizer.on("open-doc", ({ peerId, documentId }) => {
      if (this.#remoteHeadsGossipingEnabled) {
        this.#remoteHeadsSubscriptions.subscribePeerToDoc(peerId, documentId)
      }
    })

    // When we get a new peer, register it with the synchronizer
    networkSubsystem.on("peer", async ({ peerId, peerMetadata }) => {
      this.#log.debug("peer connected", { peerId })

      if (peerMetadata) {
        this.peerMetadataByPeerId[peerId] = { ...peerMetadata }
      }

      this.#shareConfig
        .announce(peerId)
        .then(shouldShare => {
          if (shouldShare && this.#remoteHeadsGossipingEnabled) {
            this.#remoteHeadsSubscriptions.addGenerousPeer(peerId)
          }
        })
        .catch(err => {
          this.#log.error("error in share policy", { err })
        })

      this.synchronizer.addPeer(peerId)
    })

    // When a peer disconnects, remove it from the synchronizer
    networkSubsystem.on("peer-disconnected", ({ peerId }) => {
      this.synchronizer.removePeer(peerId)
      this.#remoteHeadsSubscriptions.removePeer(peerId)
    })

    // Inbound messages are untrusted peer input, so #receiveMessage can throw on
    // a malformed or cross-version message. An EventEmitter does not trap a
    // listener's exception, so an uncaught throw here aborts the emit() dispatch
    // (other listeners skipped) and unwinds back through the transport's
    // event-loop callback that delivered the message. In Node an uncaught error
    // there terminates the process by default, so one bad message could take
    // down a sync server; in a browser it is only logged. Catch it.
    // See https://nodejs.org/api/process.html#event-uncaughtexception
    networkSubsystem.on("message", msg => {
      try {
        this.#receiveMessage(msg)
      } catch (err) {
        this.#log.error("error handling inbound message", err)
      }
    })

    this.synchronizer.on("sync-state", message => {
      const handle = this.#queries[message.documentId]?.handle
      if (!handle) return

      const peerMeta = this.peerMetadataByPeerId[message.peerId]
      const change = this.#syncStateTracker.handleSyncState(
        message,
        peerMeta,
        handle
      )

      if (change && this.#remoteHeadsGossipingEnabled) {
        this.#remoteHeadsSubscriptions.handleImmediateRemoteHeadsChanged(
          message.documentId,
          change.storageId,
          change.heads
        )
      }
    })

    if (this.#remoteHeadsGossipingEnabled) {
      this.#remoteHeadsSubscriptions.on("notify-remote-heads", message => {
        this.networkSubsystem.send({
          type: "remote-heads-changed",
          targetId: message.targetId,
          documentId: message.documentId,
          newHeads: {
            [message.storageId]: {
              heads: message.heads,
              timestamp: message.timestamp,
            },
          },
        })
      })

      this.#remoteHeadsSubscriptions.on("change-remote-subs", message => {
        this.#log.debug("change-remote-subs", message)
        for (const peer of message.peers) {
          this.networkSubsystem.send({
            type: "remote-subscription-change",
            targetId: peer,
            add: message.add,
            remove: message.remove,
          })
        }
      })

      this.#remoteHeadsSubscriptions.on(
        "remote-heads-changed",
        ({ documentId, storageId, remoteHeads, timestamp }) => {
          const handle = this.#queries[documentId]?.handle
          if (!handle) return
          this.#syncStateTracker.handleRemoteHeadsChanged(
            documentId,
            storageId,
            remoteHeads,
            timestamp,
            handle
          )
        }
      )
    }
  }

  /**
   * Create a query, handle, set up all sources, and register with the sync
   * layer. Safe to call multiple times — attach no-ops if the document
   * is already registered. Used by findWithProgress (outbound), create/import,
   * and the CollectionSynchronizer's ensureQuery callback (inbound).
   *
   * If `initialDoc` is provided (create/import path), storage loading is
   * skipped and the doc is applied after registration so that the storage
   * listener captures the initial data.
   */
  #ensureQuery(
    documentId: DocumentId,
    initialDoc?: unknown,
    documentType: AnyDocumentType = this.#automergeDocumentType
  ): DocumentQuery<unknown, DocHandle<any, any>> {
    const crdtName = documentType.name
    const existing = this.#queries[documentId]
    if (existing) {
      if (existing.handle.crdtName !== crdtName) {
        throw new Error(
          `Document ${documentId} is already open as ${existing.handle.crdtName}, not ${crdtName}`
        )
      }
      return existing
    }

    const emptyState = () =>
      documentType.empty({ documentId, peerId: this.#peerId, crdtName })

    const document = new Document(
      documentId,
      initialDoc ?? emptyState(),
      storageId => this.#syncStateTracker.getSyncInfo(documentId, storageId),
      { documentType, crdtName, peerId: this.#peerId }
    )
    const handle = new DocHandle(document, {})
    const query = new DocumentQuery(handle, this.#sources)
    this.#queries[documentId] = query

    // Attach all sources. Each source calls sourcePending/sourceUnavailable
    // as appropriate and sets up its own listeners. When initialDoc is
    // provided the handle already has data, so sources see a ready handle
    // from the start.
    for (const source of this.#sources.values()) {
      source.attach(query)
    }

    // Bridge outbound ephemeral messages to Subduction.
    // This fires once per DocHandle.broadcast() call, independent of
    // whether there are any old-protocol sync peers.
    if (this.#subductionSource) {
      const subductionSource = this.#subductionSource
      query.handle.on("ephemeral-message-outbound", ({ data }) => {
        console.log(
          `[repo] ephemeral outbound for ${documentId.slice(0, 8)}, ${
            data.byteLength
          } bytes`
        )
        const fullMsg: EphemeralMessage = {
          type: "ephemeral",
          senderId: this.#peerId,
          targetId: this.#peerId, // not meaningful for pub/sub
          documentId,
          data,
          count: this.#subductionEphemeralCount++,
          sessionId: "subduction-bridge" as SessionId,
        }
        const payload = new Uint8Array(encode(fullMsg))
        void subductionSource.publishEphemeral(documentId, payload)
      })
    }

    return query
  }

  #receiveMessage(message: RepoMessage) {
    switch (message.type) {
      case "remote-subscription-change":
        if (this.#remoteHeadsGossipingEnabled) {
          this.#remoteHeadsSubscriptions.handleControlMessage(message)
        }
        break
      case "remote-heads-changed":
        if (this.#remoteHeadsGossipingEnabled) {
          this.#remoteHeadsSubscriptions.handleRemoteHeads(message)
        }
        break
      case "sync":
      case "request":
      case "ephemeral":
      case "doc-unavailable":
        this.synchronizer.receiveMessage(message)
        break
    }
  }

  /** Returns all the handles we have cached. */
  get handles(): Record<DocumentId, DocHandle<any>> {
    const result: Record<DocumentId, DocHandle<any>> = {}
    for (const [id, query] of Object.entries(this.#queries)) {
      if (query.handle) {
        result[id as DocumentId] = query.handle
      }
    }
    return result
  }

  /** Returns a list of all connected peer ids */
  get peers(): PeerId[] {
    return this.synchronizer.peers
  }

  /** Returns the local peer id */
  get peerId(): PeerId {
    return this.networkSubsystem.peerId
  }

  /** @hidden */
  get sharePolicy(): SharePolicy {
    return this.#shareConfig.announce
  }

  /** @hidden */
  set sharePolicy(policy: SharePolicy) {
    this.#shareConfig.announce = policy
  }

  /** @hidden */
  get shareConfig(): ShareConfig {
    return this.#shareConfig
  }

  /** @hidden */
  set shareConfig(config: ShareConfig) {
    this.#shareConfig = config
  }

  get subduction(): Promise<Subduction> {
    if (!this.#subductionSource) {
      return Promise.reject(new Error("Repo has no SubductionSource"))
    }
    return this.#subductionSource.getSubduction()
  }

  getStorageIdOfPeer(peerId: PeerId): StorageId | undefined {
    return this.peerMetadataByPeerId[peerId]?.storageId
  }

  /**
   * Creates a new document and returns a handle to it. The initial value of the document is an
   * empty object `{}` unless an initial value is provided. Its documentId is generated by the
   * system. we emit a `document` event to advertise interest in the document.
   */
  create<C extends AnyDocumentType>(documentType: C): CrdtDocHandle<C>
  create<C extends AnyDocumentType>(
    initialValue: InitOf<C>,
    documentType: C
  ): CrdtDocHandle<C>
  create<T>(initialValue?: T): DocHandle<T>
  create(
    initialValueOrDocumentType?: unknown,
    maybeDocumentType?: AnyDocumentType
  ): DocHandle<any, any> {
    if (maybeDocumentType !== undefined && !isDocumentType(maybeDocumentType)) {
      throw new Error(
        "Repo.create expected a document type object as its second argument"
      )
    }

    const documentType = isDocumentType(initialValueOrDocumentType)
      ? initialValueOrDocumentType
      : (maybeDocumentType ?? this.#automergeDocumentType)
    const initialValue = isDocumentType(initialValueOrDocumentType)
      ? undefined
      : initialValueOrDocumentType
    const crdtName = documentType.name

    const { documentId } = parseAutomergeUrl(generateAutomergeUrl())
    const initialDoc = documentType.init(initialValue, {
      documentId,
      peerId: this.#peerId,
      crdtName,
    })
    const query = this.#ensureQuery(documentId, initialDoc, documentType)
    return query.handle
  }

  /**
   * Creates a new document and returns a handle to it. The initial value of the
   * document is an empty object `{}` unless an initial value is provided. The
   * main difference between this and Repo.create is that if an `idGenerator`
   * was provided at repo construction, that idGenerator will be used to
   * generate the document ID of the document returned by this method.
   *
   * This is a hidden, experimental API which is subject to change or removal without notice.
   * @hidden
   * @experimental
   */
  async create2<T>(initialValue?: T): Promise<DocHandle<T>> {
    // Note that the reason this method is hidden and experimental is because it is async,
    // and it is async because we want to be able to call the #idGenerator, which is async.
    // This is all really in service of wiring up keyhive and we probably need to find a
    // nicer way to achieve this.
    let initialDoc: Automerge.Doc<T>
    if (initialValue) {
      initialDoc = Automerge.from(initialValue)
    } else {
      initialDoc = Automerge.emptyChange(Automerge.init())
    }

    let { documentId } = parseAutomergeUrl(generateAutomergeUrl())
    if (this.#idFactory) {
      const rawDocId = await this.#idFactory(Automerge.getHeads(initialDoc))
      documentId = binaryToDocumentId(rawDocId as BinaryDocumentId)
    }
    const query = this.#ensureQuery(
      documentId,
      initialDoc as Automerge.Doc<unknown>
    )
    return query.handle as DocHandle<T>
  }

  /** Create a new DocHandle by cloning the history of an existing DocHandle.
   *
   * @param clonedHandle - The handle to clone
   *
   * @remarks This is a wrapper around the `clone` function in the Automerge library.
   * The new `DocHandle` will have a new URL but will share history with the original,
   * which means that changes made to the cloned handle can be sensibly merged back
   * into the original.
   *
   * Any peers this `Repo` is connected to for whom `sharePolicy` returns `true` will
   * be notified of the newly created DocHandle.
   *
   */
  clone<T>(clonedHandle: DocHandle<T>) {
    if (!clonedHandle.isAutomerge()) {
      throw new Error("Cannot clone non-Automerge documents yet")
    }
    const sourceDoc = clonedHandle.fullDoc() as Automerge.Doc<T>
    const handle = this.create<T>()
    handle.update(() => Automerge.clone(sourceDoc) as any)
    return handle
  }

  /**
   * Returns a `DocumentProgress` for the given document. This is a reactive,
   * read-only view that tracks the ongoing state of the document.
   *
   * Use `subscribe` to observe state changes and `peek` to read the current
   * state. The `handle` is only available when the state is `"ready"`.
   */
  findWithProgress<C extends AnyDocumentType>(
    id: AnyDocumentId,
    documentType: C,
    options?: AbortOptions
  ): DocumentProgress<C, CrdtDocHandle<C>>
  findWithProgress<T = unknown>(
    id: AnyDocumentId,
    options?: AbortOptions
  ): DocumentProgress<T, DocHandle<T>>
  findWithProgress(
    id: AnyDocumentId,
    documentTypeOrOptions?: AnyDocumentType | AbortOptions,
    // the original automerge-repo v2 accepted `AbortOptions` here which could
    // be passed an abort signal. For now we accept the signal to remain backwards
    // compatible but ignore it. The main feature we miss vs the original API is the
    // ability to not create a doc handle if we abort while loading. Once the DocHandle
    // was running the abort signal didn't have much effect
    _options?: AbortOptions
  ): DocumentProgress<any, DocHandle<any, any>> {
    if (
      documentTypeOrOptions !== undefined &&
      !isDocumentType(documentTypeOrOptions) &&
      (typeof documentTypeOrOptions !== "object" ||
        documentTypeOrOptions === null)
    ) {
      throw new Error(
        "Repo.findWithProgress expected a document type object as its second argument"
      )
    }

    const explicitDocumentType = isDocumentType(documentTypeOrOptions)
      ? documentTypeOrOptions
      : undefined
    const parsed = isValidAutomergeUrl(id)
      ? parseAutomergeUrl(id)
      : {
          documentId: interpretAsDocumentId(id),
          heads: undefined,
          segments: undefined,
        }
    const { documentId, heads, segments } = parsed
    const documentType =
      explicitDocumentType ??
      this.#queries[documentId]?.handle.documentType ??
      this.#automergeDocumentType
    const crdtName = documentType.name

    // ensureQuery creates the query, handle, sets up all sources, and
    // registers with the sync layer (no-ops if already added).
    if (!this.#queries[documentId]) {
      this.#ensureQuery(documentId, undefined, documentType)
    } else if (this.#queries[documentId].handle.crdtName !== crdtName) {
      throw new Error(
        `Document ${documentId} is already open as ${this.#queries[documentId].handle.crdtName}, not ${crdtName}`
      )
    }
    const query = this.#queries[documentId] as DocumentQuery<
      any,
      DocHandle<any, any>
    >

    // A URL can carry both fixed heads (`#h1|h2`) and a path suffix
    // (`/a/@0/b`). Layer the heads projection first (it gates readiness on
    // those heads being present), then scope to the path. The two compose
    // to the same canonical handle regardless of order.
    let progress: DocumentProgress<any, DocHandle<any, any>> = query
    if (heads) progress = progressAtHeads(query, heads)
    if (segments && segments.length > 0) {
      progress = progressAtPath(progress, segments)
    }
    return progress
  }

  /**
   * Look up a document by URL and wait for it to be ready.
   */
  async find<C extends AnyDocumentType>(
    id: AnyDocumentId,
    documentType: C,
    options?: RepoFindOptions & AbortOptions
  ): Promise<CrdtDocHandle<C>>
  async find<T = unknown>(
    id: AnyDocumentId,
    options?: RepoFindOptions & AbortOptions
  ): Promise<DocHandle<T>>
  async find(
    id: AnyDocumentId,
    documentTypeOrOptions:
      | AnyDocumentType
      | (RepoFindOptions & AbortOptions) = {},
    maybeOptions: RepoFindOptions & AbortOptions = {}
  ): Promise<DocHandle<any, any>> {
    if (
      documentTypeOrOptions !== undefined &&
      !isDocumentType(documentTypeOrOptions) &&
      (typeof documentTypeOrOptions !== "object" ||
        documentTypeOrOptions === null)
    ) {
      throw new Error(
        "Repo.find expected a document type object as its second argument"
      )
    }

    const documentType = isDocumentType(documentTypeOrOptions)
      ? documentTypeOrOptions
      : undefined
    const options: RepoFindOptions & AbortOptions = documentType
      ? maybeOptions
      : (documentTypeOrOptions as RepoFindOptions & AbortOptions)
    const { signal } = options

    if (signal?.aborted) {
      throw new AbortError()
    }

    // `findWithProgress` already applies any path suffix (`/a/@0/b`) and
    // fixed heads (`#h1|h2`) from the URL, so the ready handle is correctly
    // scoped and/or view-pinned.
    return documentType
      ? this.findWithProgress(id, documentType).whenReady({ signal })
      : this.findWithProgress(id).whenReady({ signal })
  }

  /**
   * @deprecated Alias for {@link Repo.find}. Will be removed in the next major release
   */
  findClassic<T>(
    id: AnyDocumentId,
    options: RepoFindOptions & AbortOptions = {}
  ): Promise<DocHandle<T>> {
    return this.find<T>(id, options) as unknown as Promise<DocHandle<T>>
  }

  delete(id: AnyDocumentId) {
    const documentId = interpretAsDocumentId(id)

    const query = this.#queries[documentId]
    if (query?.handle) {
      // Fans out to all retained handles (root + subs) via the registry
      // and flips the document's `deleted` flag.
      query.handle.delete()
    }
    if (query) {
      query.fail(new Error(`Document ${documentId} was deleted`))
    }
    delete this.#queries[documentId]

    for (const source of this.#sources.values()) {
      source.detach(documentId)
    }
    this.#syncStateTracker.delete(documentId)

    if (this.storageSubsystem) {
      this.storageSubsystem.removeDoc(documentId).catch(err => {
        this.#log.error("error deleting document from storage", {
          documentId,
          err,
        })
      })
    }

    this.emit("delete-document", { documentId })
  }

  /**
   * Exports a document to a binary format.
   * @param id - The url or documentId of the handle to export
   *
   * @returns Promise<Uint8Array | undefined> - A Promise containing the binary document,
   * or undefined if the document is unavailable.
   */
  async export(id: AnyDocumentId): Promise<Uint8Array | undefined> {
    const handle = await this.find(id)
    if (!handle.isAutomerge()) {
      throw new Error(
        `Cannot export non-Automerge document ${handle.documentId}`
      )
    }
    return Automerge.save(handle.fullDoc() as Automerge.Doc<unknown>)
  }

  /**
   * Imports document binary into the repo.
   * @param binary - The binary to import
   * @param args - Optional argument specifying what document ID to import into,
   *              if at all possible avoid using this, see the remarks below
   *
   * @remarks
   * If no document ID is provided, a new document will be created. When
   * specifying the document ID it is important to ensure that two documents using
   * the same ID share the same history - i.e. don't create a document with the
   * same ID on unrelated processes that have never communicated with each
   * other. If you need to ship around a bunch of documents with their IDs
   * consider using the `automerge-repo-bundles` package which provides a
   * serialization format for documents and IDs and handles the boilerplate of
   * importing and exporting these bundles.
   */
  import<T>(binary: Uint8Array, args?: { docId?: DocumentId }): DocHandle<T> {
    const docId = args?.docId
    if (docId != null) {
      // Check if we already have a handle for this document
      const existing = this.#queries[docId]?.handle as DocHandle<T> | null
      if (existing) {
        existing.update(
          doc =>
            Automerge.loadIncremental(doc as Automerge.Doc<T>, binary) as any
        )
        return existing
      }
      const initialDoc = Automerge.load<T>(binary)
      const query = this.#ensureQuery(
        docId,
        initialDoc as Automerge.Doc<unknown>
      )
      return query.handle as DocHandle<T>
    } else {
      const doc = Automerge.load<T>(binary)
      const { documentId } = parseAutomergeUrl(generateAutomergeUrl())
      const query = this.#ensureQuery(
        documentId,
        Automerge.clone(doc) as Automerge.Doc<unknown>
      )
      return query.handle as DocHandle<T>
    }
  }

  subscribeToRemotes = (remotes: StorageId[]) => {
    if (this.#remoteHeadsGossipingEnabled) {
      this.#log.debug("subscribeToRemotes", { remotes })
      this.#remoteHeadsSubscriptions.subscribeToRemotes(remotes)
    } else {
      this.#log.warn(
        "subscribeToRemotes called but remote heads gossiping is not enabled"
      )
    }
  }

  storageId = async (): Promise<StorageId | undefined> => {
    if (!this.storageSubsystem) {
      return undefined
    } else {
      return this.storageSubsystem.id()
    }
  }

  /**
   * Drain pending writes for the given documents (or all documents
   * when `documents` is omitted) so they are durable in storage.
   *
   * Saves each ready document's Automerge bytes via the
   * `StorageSubsystem`'s snapshot path and asks every registered
   * {@link DocumentSource} that implements `flush` to drain its own
   * buffered writes. Resolves once everything has settled.
   *
   * @hidden this API is experimental and may change.
   * @param documents - if provided, only flushes the specified documents.
   */
  async flush(documents?: DocumentId[]): Promise<void> {
    const tasks: Promise<unknown>[] = []

    if (this.storageSubsystem) {
      const ids = documents ?? (Object.keys(this.#queries) as DocumentId[])
      tasks.push(
        Promise.all(
          ids.map(async id => {
            const state = this.#queries[id]?.peek()
            if (state?.state === "ready" && state.handle.isAutomerge()) {
              await this.storageSubsystem!.saveDoc(
                id,
                state.handle.fullDoc() as Automerge.Doc<unknown>
              )
            }
          })
        )
      )
    }

    for (const source of this.#sources.values()) {
      if (source.flush) tasks.push(source.flush(documents))
    }

    await Promise.all(tasks)
  }

  /**
   * Removes a DocHandle from the handleCache.
   * @hidden this API is experimental and may change.
   * @param documentId - documentId of the DocHandle to remove from handleCache, if present in cache.
   */
  async removeFromCache(documentId: DocumentId): Promise<void> {
    for (const source of this.#sources.values()) {
      source.detach(documentId)
    }
    delete this.#queries[documentId]
    this.#syncStateTracker.delete(documentId)
  }

  async shutdown() {
    // Quiesce Subduction first — stops reconnect loops, flushes pending
    // saves, awaits storage writes, disconnects transports, frees Wasm
    await this.#subductionSource?.shutdown()

    // Stop traditional sync network connections
    this.networkSubsystem.disconnect()

    // Best-effort flush: log persistence errors but don't propagate,
    // so the rest of teardown still runs. Call `repo.flush()`
    // explicitly before `shutdown()` if you need to observe them.
    try {
      await this.flush()
    } catch (e) {
      this.#log.warn("flush() during shutdown failed", { err: e })
    }
  }

  metrics(): { documents: { [key: string]: any } } {
    return { documents: this.synchronizer.metrics() }
  }

  shareConfigChanged() {
    for (const source of this.#sources.values()) {
      source.shareConfigChanged()
    }
  }
}

export interface RepoConfig {
  /** Our unique identifier */
  peerId?: PeerId

  /** Indicates whether other peers should persist the sync state of this peer.
   * Sync state is only persisted for non-ephemeral peers */
  isEphemeral?: boolean

  /** A storage adapter can be provided, or not */
  storage?: StorageAdapterInterface

  /** A list of network adapters (more can be added at runtime). */
  network?: NetworkAdapterInterface[]

  /**
   * Normal peers typically share generously with everyone (meaning we sync all our documents with
   * all peers). A server only syncs documents that a peer explicitly requests by ID.
   */
  sharePolicy?: SharePolicy

  /**
   * Whether to share documents with other peers. By default we announce new
   * documents to everyone and allow everyone access to documents, see the
   * documentation for {@link ShareConfig} to override this
   *
   * Note that this is currently an experimental API and will very likely change
   * without a major release.
   * @experimental
   */
  shareConfig?: ShareConfig

  /**
   * Whether to enable the experimental remote heads gossiping feature
   */
  enableRemoteHeadsGossiping?: boolean

  /**
   * A list of automerge URLs which should never be loaded regardless of what
   * messages are received or what the share policy is. This is useful to avoid
   * loading documents that are known to be too resource intensive.
   */
  denylist?: AutomergeUrl[]

  /**
   * The debounce rate in milliseconds for saving documents. Defaults to 100ms.
   */
  saveDebounceRate?: number

  // This is hidden for now because it's an experimental API, mostly here in order
  // for keyhive to be able to control the ID generation
  /**
   * @hidden
   */
  idFactory?: (initialHeads: Heads) => Promise<Uint8Array>

  /**
   * Signer used for Subduction commit signatures and peer identity.
   * Defaults to a fresh `MemorySigner` (ephemeral key, lost on restart).
   * Pass a `WebCryptoSigner` (via `await WebCryptoSigner.setup()`) for
   * persistent identity across page loads.
   */
  signer?: unknown

  /** Authorization policy for the Subduction sync engine. See {@link Policy} from `@automerge/automerge-subduction`. */
  subductionPolicy?: SubductionPolicy

  subductionWebsocketEndpoints?: string[]

  subductionAdapters?: {
    adapter: NetworkAdapterInterface
    serviceName: string
    /** Whether to initiate ("connect") or accept ("accept") the subduction
     *  handshake for peers on this adapter. Defaults to "connect". */
    role?: "connect" | "accept"
  }[]

  /**
   * Tunable timeouts for the Subduction sync engine and its
   * heal-retry scheduler. See {@link SubductionTimeouts}. All fields
   * are optional; sensible defaults apply.
   */
  subductionTimeouts?: SubductionTimeouts

  /**
   * Optional interceptor for transforming incoming and outgoing blobs (e.g.,
   * for E2EE).
   *
   * When set, this Repo's subduction commits are stored under a distinct key
   * prefix ({@link INTERCEPTOR_PREFIX}). This keeps an interceptor-transformed
   * store from colliding with an untransformed store that shares the same
   * `storage` when only one of the two Repos runs the interceptor.
   */
  subductionBlobInterceptor?: BlobInterceptor
}

/** A function that determines whether we should share a document with a peer
 *
 * @remarks
 * This function is called by the {@link Repo} every time a new document is created
 * or discovered (such as when another peer starts syncing with us). If this
 * function returns `true` then the {@link Repo} will begin sharing the new
 * document with the peer given by `peerId`.
 * */
export type SharePolicy = (
  peerId: PeerId,
  documentId?: DocumentId
) => Promise<boolean>

/**
 * A type which determines whether we should share a document with a peer
 * */
export type ShareConfig = {
  /**
   * Whether we should actively announce a document to a peer

   * @remarks
   * This functions is called after checking the `access` policy to determine
   * whether we should announce a document to a connected peer. For example, a
   * tab connected to a sync server might want to announce every document to the
   * sync server, but the sync server would not want to announce every document
   * to every connected peer
   */
  announce: SharePolicy
  /**
   * Whether a peer should have access to the document
   */
  access: (peerId: PeerId, documentId?: DocumentId) => Promise<boolean>
}

export type RepoFindOptions = {
  /**
   * @deprecated This no longer has any effect, instead you should use
   * {@link Repo.findWithProgress} to get progress information.
   */
  allowableStates?: string[]
}

// Re-exported from DocHandle
export type { SyncInfo } from "./DocHandle.js"

export type DeleteDocumentPayload = { documentId: DocumentId }
export type DocumentPayload = { handle: DocHandle<any> }
export type DocMetrics = {
  type: string
  documentId: DocumentId
  [key: string]: unknown
}

// events & payloads
export interface RepoEvents {
  /** A new document was created or discovered */
  document: (payload: DocumentPayload) => void
  /** A document was deleted */
  "delete-document": (payload: DeleteDocumentPayload) => void
  /** A document was marked as unavailable (we don't have it and none of our peers have it) */
  "unavailable-document": (payload: DeleteDocumentPayload) => void
  "doc-metrics": (payload: DocMetrics) => void
  /** Self-healing sync gave up after all retry attempts for a document */
  "heal-exhausted": (payload: { documentId: DocumentId }) => void
}
